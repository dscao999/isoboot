/* include/agent_config.h.  Generated from agent_config.h.in by configure.  */
/* Where Resouce agents keep state files */
#define HA_RSCTMPDIR "/var/run/resource-agents"

