package YAML::LibYAML;
use 5.008003;
use strict;
use warnings;
our $VERSION = '0.18';

die "YAML::LibYAML has been renamed to YAML::XS. Please use YAML::XS instead.";

1;
