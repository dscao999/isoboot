"""
The manager installs and removes packages, runs scripts and retrieves
information that is only accessible to the root user.
"""
