/* This file is auto generated, version 31~16.04.1-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#31~16.04.1-Ubuntu SMP Wed Jul 18 08:54:04 UTC 2018"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy01-amd64-024"
#define LINUX_COMPILER "gcc version 5.4.0 20160609 (Ubuntu 5.4.0-6ubuntu1~16.04.10)"
