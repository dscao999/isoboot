#define UTS_RELEASE "4.15.0-29-generic"
#define UTS_UBUNTU_RELEASE_ABI 29
